JIAM MOLLAH Digital Marketing Website
========================================
Files:
- index.html
- logo.png
- banner.png
- profile-card.png

Open index.html in a browser to preview the site.

Edit contact details, service text and pricing inside index.html as needed.
The site intentionally does not include fabricated client results or fake testimonials.
